-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2018 at 04:44 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `instanthelpdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `balance`
--

CREATE TABLE `balance` (
  `id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `depositedate` datetime NOT NULL,
  `client_id` int(11) NOT NULL COMMENT 'r1:client,email'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `calling`
--

CREATE TABLE `calling` (
  `id` int(11) NOT NULL,
  `type` enum('audio','video') NOT NULL,
  `strat` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `sender` int(11) NOT NULL COMMENT 'r1:client,email',
  `receiver` int(11) NOT NULL COMMENT 'r1:client,email'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `calling`
--

INSERT INTO `calling` (`id`, `type`, `strat`, `end`, `amount`, `status`, `sender`, `receiver`) VALUES
(2, 'audio', '2018-10-01 05:40:00', '2018-10-01 05:40:00', 4, 0, 2, 1),
(3, 'audio', '2018-11-08 22:18:00', '2018-10-01 05:40:00', 4, 2, 4, 1),
(4, 'video', '2018-11-08 23:47:28', NULL, 0, 2, 4, 1),
(5, 'video', '2018-11-09 00:14:15', NULL, 0, 2, 4, 1),
(6, 'video', '2018-11-09 00:15:29', NULL, 0, 2, 4, 1),
(7, 'video', '2018-11-09 00:15:58', NULL, 0, 2, 4, 1),
(8, 'video', '2018-11-09 00:17:13', NULL, 0, 2, 4, 1),
(9, 'video', '2018-11-09 00:23:01', NULL, 0, 2, 4, 1),
(10, 'video', '2018-11-09 00:24:35', NULL, 0, 2, 4, 1),
(11, 'video', '2018-11-09 00:25:39', NULL, 0, 2, 4, 1),
(12, 'video', '2018-11-09 00:26:58', NULL, 0, 2, 4, 1),
(13, 'video', '2018-11-09 00:28:11', NULL, 0, 2, 4, 1),
(14, 'video', '2018-11-09 00:29:28', NULL, 0, 2, 4, 1),
(15, 'video', '2018-11-09 00:30:44', NULL, 0, 2, 4, 1),
(16, 'video', '2018-11-09 00:31:24', NULL, 0, 2, 4, 1),
(17, 'video', '2018-11-09 00:33:09', NULL, 0, 2, 4, 1),
(18, 'video', '2018-11-09 00:34:01', NULL, 0, 2, 4, 1),
(19, 'video', '2018-11-09 00:35:42', NULL, 0, 2, 4, 1),
(20, 'video', '2018-11-09 00:36:59', NULL, 0, 2, 4, 1),
(21, 'video', '2018-11-09 00:37:53', NULL, 0, 2, 4, 1),
(22, 'video', '2018-11-09 00:39:11', NULL, 0, 2, 4, 1),
(23, 'video', '2018-11-09 01:25:52', NULL, 0, 2, 4, 1),
(24, 'video', '2018-11-09 01:26:40', NULL, 0, 2, 4, 1),
(25, 'video', '2018-11-09 01:27:31', NULL, 0, 2, 4, 1),
(26, 'video', '2018-11-09 01:28:10', NULL, 0, 2, 4, 1),
(27, 'video', '2018-11-09 01:29:13', NULL, 0, 2, 4, 1),
(28, 'video', '2018-11-09 01:33:09', NULL, 0, 4, 4, 1),
(29, 'video', '2018-11-09 01:37:09', NULL, 0, 4, 4, 1),
(30, 'video', '2018-11-09 01:38:13', NULL, 0, 2, 4, 1),
(31, 'video', '2018-11-09 01:40:19', NULL, 0, 2, 4, 1),
(32, 'video', '2018-11-09 01:40:55', NULL, 0, 2, 4, 1),
(33, 'video', '2018-11-09 01:43:39', NULL, 0, 2, 4, 1),
(34, 'video', '2018-11-09 01:45:10', NULL, 0, 2, 4, 1),
(35, 'video', '2018-11-09 01:51:48', NULL, 0, 2, 4, 1),
(36, 'video', '2018-11-09 01:52:34', NULL, 0, 2, 4, 1),
(37, 'video', '2018-11-09 01:53:34', NULL, 0, 2, 4, 1),
(38, 'video', '2018-11-09 01:58:52', NULL, 0, 2, 4, 1),
(39, 'video', '2018-11-09 02:00:25', NULL, 0, 2, 4, 1),
(40, 'video', '2018-11-09 02:00:59', NULL, 0, 2, 4, 1),
(41, 'video', '2018-11-09 02:03:07', NULL, 0, 2, 4, 1),
(42, 'video', '2018-11-09 02:03:49', NULL, 0, 4, 4, 1),
(43, 'video', '2018-11-09 02:05:23', NULL, 0, 2, 4, 1),
(44, 'video', '2018-11-09 02:08:06', NULL, 0, 4, 4, 1),
(45, 'video', '2018-11-09 02:10:19', NULL, 0, 4, 4, 1),
(46, 'video', '2018-11-09 02:15:37', NULL, 0, 4, 4, 1),
(47, 'video', '2018-11-09 02:18:12', NULL, 0, 2, 4, 1),
(48, 'video', '2018-11-09 02:20:42', NULL, 0, 4, 4, 1),
(49, 'video', '2018-11-09 02:22:00', NULL, 0, 4, 4, 1),
(50, 'video', '2018-11-09 02:25:19', NULL, 0, 3, 4, 1),
(51, 'video', '2018-11-09 02:28:07', NULL, 0, 3, 4, 1),
(52, 'video', '2018-11-09 02:30:05', NULL, 5, 3, 4, 1),
(53, 'video', '2018-11-09 02:32:33', NULL, 5, 3, 4, 1),
(54, 'video', '2018-11-09 02:36:53', NULL, 5, 3, 4, 1),
(55, 'video', '2018-11-09 02:43:37', NULL, 5, 3, 4, 1),
(56, 'video', '2018-11-09 02:52:38', NULL, 5, 3, 4, 1),
(57, 'video', '2018-11-09 02:55:34', NULL, 5, 3, 4, 1),
(58, 'video', '2018-11-09 03:00:42', NULL, 5, 3, 4, 1),
(59, 'video', '2018-11-09 03:03:13', NULL, 5, 3, 4, 1),
(60, 'video', '2018-11-09 03:05:32', NULL, 5, 3, 4, 1),
(61, 'video', '2018-11-09 16:35:31', NULL, 0, 3, 4, 1),
(62, 'video', '2018-11-09 16:38:11', NULL, 5, 3, 4, 1),
(63, 'video', '2018-11-09 16:38:18', NULL, 4, 2, 4, 1),
(64, 'video', '2018-11-09 16:41:07', NULL, 5, 3, 4, 1),
(65, 'video', '2018-11-09 16:41:13', NULL, 5, 2, 4, 1),
(66, 'video', '2018-11-09 16:45:48', NULL, 5, 3, 4, 1),
(67, 'video', '2018-11-09 16:45:52', NULL, 5, 3, 4, 1),
(68, 'video', '2018-11-09 16:45:58', NULL, 1, 3, 4, 1),
(69, 'video', '2018-11-09 16:52:15', NULL, 2, 3, 4, 1),
(70, 'video', '2018-11-09 16:52:22', NULL, 0, 3, 4, 1),
(71, 'video', '2018-11-09 17:02:24', NULL, 3, 3, 4, 1),
(72, 'video', '2018-11-09 17:04:10', NULL, 4, 3, 4, 1),
(73, 'video', '2018-11-09 20:25:38', NULL, 5, 3, 4, 1),
(74, 'video', '2018-11-09 20:27:21', NULL, 3, 3, 4, 1),
(75, 'video', '2018-11-09 20:53:22', NULL, 0, 3, 4, 1),
(76, 'video', '2018-11-09 21:45:17', NULL, 0, 2, 4, 1),
(77, 'video', '2018-11-09 21:49:25', NULL, 0, 2, 4, 1),
(78, 'video', '2018-11-09 21:50:38', NULL, 0, 3, 4, 1),
(79, 'video', '2018-11-09 23:34:08', NULL, 0, 3, 4, 1),
(80, 'video', '2018-11-09 23:42:34', NULL, 0, 3, 4, 1),
(81, 'video', '2018-11-09 23:45:56', NULL, 0, 3, 4, 1),
(82, 'video', '2018-11-09 23:47:28', NULL, 0, 3, 4, 1),
(83, 'video', '2018-11-09 23:47:56', NULL, 0, 3, 4, 1),
(84, 'video', '2018-11-09 23:49:36', NULL, 0, 3, 4, 1),
(85, 'video', '2018-11-09 23:50:19', NULL, 0, 3, 4, 1),
(86, 'video', '2018-11-09 23:51:26', NULL, 0, 3, 4, 1),
(87, 'video', '2018-11-10 02:14:49', NULL, 0, 4, 4, 1),
(88, 'video', '2018-11-10 02:15:24', NULL, 0, 4, 4, 1),
(89, 'video', '2018-11-10 02:29:43', NULL, 0, 4, 4, 1),
(90, 'video', '2018-11-10 02:31:35', '2018-11-10 02:31:54', 4, 3, 4, 1),
(91, 'video', '2018-11-10 03:27:52', NULL, 0, 2, 4, 1),
(92, 'video', '2018-11-10 03:31:12', NULL, 0, 2, 4, 1),
(93, 'video', '2018-11-10 03:32:36', NULL, 0, 2, 4, 1),
(94, 'video', '2018-11-10 03:32:57', NULL, 0, 2, 4, 1),
(95, 'video', '2018-11-10 03:44:08', NULL, 0, 2, 4, 1),
(96, 'video', '2018-11-10 03:50:15', NULL, 0, 2, 4, 1),
(97, 'video', '2018-11-10 03:50:53', NULL, 0, 0, 4, 1),
(98, 'video', '2018-11-28 22:52:50', NULL, 0, 4, 1, 4),
(99, 'video', '2018-11-28 22:53:28', NULL, 0, 4, 1, 4),
(100, 'video', '2018-11-28 22:55:34', NULL, 0, 4, 1, 4),
(101, 'video', '2018-11-28 22:58:34', NULL, 0, 4, 4, 1),
(102, 'video', '2018-11-29 11:57:37', NULL, 0, 4, 1, 4),
(103, 'video', '2018-11-29 11:58:26', NULL, 0, 4, 1, 4),
(104, 'video', '2018-12-12 19:19:57', NULL, 0, 4, 4, 1),
(105, 'video', '2018-12-12 19:21:01', '2018-12-12 19:21:31', 3, 3, 4, 1),
(106, 'video', '2018-12-13 02:13:59', '2018-12-13 02:14:59', 2, 3, 1, 4),
(107, 'video', '2018-12-13 02:15:15', NULL, 0, 4, 1, 4),
(108, 'video', '2018-12-13 02:22:39', '2018-12-13 02:23:21', 2, 3, 1, 4),
(109, 'video', '2018-12-13 02:23:41', NULL, 0, 4, 4, 1),
(110, 'video', '2018-12-13 02:24:58', NULL, 0, 4, 4, 1),
(111, 'video', '2018-12-13 02:28:15', NULL, 0, 4, 4, 1),
(112, 'video', '2018-12-13 02:28:48', NULL, 0, 4, 4, 1),
(113, 'video', '2018-12-13 02:29:29', '2018-12-13 02:29:57', 3, 3, 1, 4),
(114, 'video', '2018-12-13 11:37:49', '2018-12-13 11:38:28', 4, 3, 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `guid` varchar(100) NOT NULL,
  `fname` varchar(45) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `photo` varchar(45) DEFAULT NULL COMMENT 'image upload: jpeg, png, gif, jpg, mpg',
  `country` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `clientStatus` int(11) NOT NULL COMMENT 'dropdown:clientStatus',
  `level` int(11) DEFAULT NULL,
  `available` tinyint(1) DEFAULT '0' COMMENT 'Yes, No',
  `clientType` int(11) NOT NULL COMMENT 'dropdown:clientType',
  `bankaccount` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `guid`, `fname`, `lname`, `email`, `password`, `photo`, `country`, `city`, `address`, `clientStatus`, `level`, `available`, `clientType`, `bankaccount`) VALUES
(1, '2F56D752-3FFE-028A-FC15-7F339927245D', 'Mohammad', 'Mohammad', 'it.msm88@gmail.com', '2c216b1ba5e33a27eb6d3df7de7f8c36', '456690personal photo.jpg', 'Hungary', 'dhfureoigf', 'Kerekes Utca, Kerekes', 1, NULL, 1, 1, NULL),
(2, '00846F37-8BDC-5941-5D5A-51A6480F37B2', 'Ali', 'Ahmed', 'it.msm7@gmail.com', '1qaz2wsx', NULL, NULL, 'Budapest', NULL, 1, NULL, 1, 2, NULL),
(3, 'B1140E7E-1AF2-7475-CBAE-4F5F1F208557', 'Rami', 'Mourani', 'it.msm2@gmail.com', '1qaz2wsx', NULL, NULL, 'London', NULL, 1, NULL, 1, 1, NULL),
(4, '0E5A2249-5DBD-28E4-9A68-283C9AE3E2CE', 'Wisam', 'Darwish', 'wisam.darwish@gmail.com', '2c216b1ba5e33a27eb6d3df7de7f8c36', '164014wisam.jpg', NULL, 'Paris', NULL, 1, NULL, 1, 2, NULL),
(5, 'B09BEC07-6E4F-86BC-2803-3E1B0F241E12', 'Rami', 'Morani', 'it.msm66@gmail.com', '2c216b1ba5e33a27eb6d3df7de7f8c36', NULL, NULL, NULL, NULL, 1, NULL, 1, 3, NULL),
(6, 'F1722446-B660-A0EB-786D-0C9EAA2A8B59', 'Wisam', 'Darish', 'it.msm77@gmail.com', '2c216b1ba5e33a27eb6d3df7de7f8c36', NULL, NULL, NULL, NULL, 1, NULL, 0, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `competence`
--

CREATE TABLE `competence` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` tinytext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `competence`
--

INSERT INTO `competence` (`id`, `name`, `description`) VALUES
(1, 'Machine Learning Engineer', 'Machine learning engineers build, implement, and maintain machine learning systems in technology products. They focus on machine learning system reliability, performance, and scalability. This career path requires you to have expert-level programming skil'),
(2, 'Data Engineer', 'Data engineers design, build, and maintain data architectures for large-scale applications. They manage the entire data lifecycle: ingestion, processing, surfacing, and storage. This career path requires strong software engineering skills'),
(3, 'Data Scientist', 'Data Scientists perform sophisticated empirical analysis to understand and make predictions about complex systems. They draw on methods and tooling from probability and statistics, mathematics, and computer science and primarily focus on extracting insigh'),
(4, 'Data Analyst', 'Data Analysts use tools such as Excel, Tableau, SQL, R or Python to use data to answer specific questions. Analysts must have a deep understanding of their organization’s data. This career path requires you to be able to visualize data in ways that help'),
(5, 'Law Consulting', ''),
(6, 'Translating from Hungarian to English', '');

-- --------------------------------------------------------

--
-- Table structure for table `competence_has_client`
--

CREATE TABLE `competence_has_client` (
  `id` int(11) NOT NULL,
  `competence_id` int(11) NOT NULL COMMENT 'r1:competence,name',
  `client_id` int(11) NOT NULL COMMENT 'r1:client,email'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `competence_has_client`
--

INSERT INTO `competence_has_client` (`id`, `competence_id`, `client_id`) VALUES
(3, 5, 3),
(4, 3, 4),
(5, 6, 3),
(6, 2, 2),
(7, 2, 3),
(18, 3, 1),
(19, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `language`
--

CREATE TABLE `language` (
  `id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `code` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `language`
--

INSERT INTO `language` (`id`, `name`, `code`) VALUES
(2, 'Arabic', 'ar'),
(3, 'Hungary', 'hu'),
(4, 'France', 'fr'),
(10, 'English', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `language_has_client`
--

CREATE TABLE `language_has_client` (
  `id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL COMMENT 'r1:language,name',
  `client_id` int(11) NOT NULL COMMENT 'r1:client,email'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `language_has_client`
--

INSERT INTO `language_has_client` (`id`, `language_id`, `client_id`) VALUES
(1, 10, 2),
(2, 2, 2),
(15, 10, 1),
(16, 3, 1),
(17, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `lastLoginTime` varchar(100) DEFAULT NULL,
  `salt` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `image` varchar(200) NOT NULL COMMENT 'image upload: jpeg, png, gif, jpg',
  `profile` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `balance`
--
ALTER TABLE `balance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `calling`
--
ALTER TABLE `calling`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `competence`
--
ALTER TABLE `competence`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `competence_has_client`
--
ALTER TABLE `competence_has_client`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `language`
--
ALTER TABLE `language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `language_has_client`
--
ALTER TABLE `language_has_client`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `balance`
--
ALTER TABLE `balance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `calling`
--
ALTER TABLE `calling`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `competence`
--
ALTER TABLE `competence`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `competence_has_client`
--
ALTER TABLE `competence_has_client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `language`
--
ALTER TABLE `language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `language_has_client`
--
ALTER TABLE `language_has_client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
